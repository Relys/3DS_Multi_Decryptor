#include "polarssl/aes.h"
#include <stdio.h>
#include <stdlib.h>
#include "util.h"
#include "types.h"

/* The three functions below were ripped from https://github.com/3DSGuy/Project_CTR/blob/master/ctrtool/keyset.cpp */
static int ishex(char c)
{
	if (c >= '0' && c <= '9')
		return 1;
	if (c >= 'A' && c <= 'F')
		return 1;
	if (c >= 'a' && c <= 'f')
		return 1;
	return 0;
}

static unsigned char hextobin(char c)
{
	if (c >= '0' && c <= '9')
		return c-'0';
	if (c >= 'A' && c <= 'F')
		return c-'A'+0xA;
	if (c >= 'a' && c <= 'f')
		return c-'a'+0xA;
	return 0;
}

int parsehex(const char* text, unsigned char* key) //Modified version of keyset_parse_key from link above
{
	unsigned int i, j;
	unsigned int hexcount = 0;

	for(i=0; i<32; i++)
	{
		if (ishex(text[i]))
			hexcount++;
	}

	if (hexcount != 32)
	{
		return 1;
	}

	for(i=0, j=0; i<32; i++)
	{
		if (ishex(text[i]))
		{
			if ( (j&1) == 0 )
				key[j/2] = hextobin(text[i])<<4;
			else
				key[j/2] |= hextobin(text[i]);
			j++;
		}
	}

	return 0;
}
/* End of ripped functions */



int main(int argc, char *argv[]){
	if(argc != 5){
		printf( "usage: %s input output Key IV\n", argv[0] );
		return 0;
	}

	u8 key[0x10] = {0};
	u8 iv[0x10] = {0};

	u32 result = 0;
	result |= parsehex(argv[3], key);
	result |= parsehex(argv[4], iv);
	if(result){
		printf("%s: Error parsing Key/IV.\n", argv[0]);
		return 0;
	}

	aes_context aes_ctxt;

	u32 size;
	u8 *buffer;
	u8 *in = _read_buffer(argv[1], &size);
	if(in == NULL){
		printf("%s: Could not open input file.", argv[0]);
		return 0;
	}
	buffer = (u8 *)malloc(size);


	aes_setkey_dec(&aes_ctxt, key, 0x80);
	aes_crypt_cbc(&aes_ctxt, AES_DECRYPT, size, iv, in, buffer);

	_write_buffer(argv[2], buffer, size);

	return 0;
}
