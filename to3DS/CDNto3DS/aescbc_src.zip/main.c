#include "polarssl/aes.h"
#include <stdio.h>
#include <stdlib.h>
#include "util.h"
#include "types.h"

/* The three functions below were ripped from https://github.com/3DSGuy/Project_CTR/blob/master/ctrtool/keyset.cpp */
static int ishex(char c)
{
	if (c >= '0' && c <= '9')
		return 1;
	if (c >= 'A' && c <= 'F')
		return 1;
	if (c >= 'a' && c <= 'f')
		return 1;
	return 0;
}

static unsigned char hextobin(char c)
{
	if (c >= '0' && c <= '9')
		return c-'0';
	if (c >= 'A' && c <= 'F')
		return c-'A'+0xA;
	if (c >= 'a' && c <= 'f')
		return c-'a'+0xA;
	return 0;
}

int parsehex(const char* text, unsigned char* key) //Modified version of keyset_parse_key from link above
{
	unsigned int i, j;
	unsigned int hexcount = 0;

	for(i=0; i<32; i++)
	{
		if (ishex(text[i]))
			hexcount++;
	}

	if (hexcount != 32)
	{
		return 1;
	}

	for(i=0, j=0; i<32; i++)
	{
		if (ishex(text[i]))
		{
			if ( (j&1) == 0 )
				key[j/2] = hextobin(text[i])<<4;
			else
				key[j/2] |= hextobin(text[i]);
			j++;
		}
	}

	return 0;
}
/* End of ripped functions */



int main(int argc, char *argv[]){
	if(argc != 5){
		printf( "usage: %s input output Key IV\n", argv[0] );
		return 0;
	}

	u8 key[0x10] = {0};
	u8 iv[0x10] = {0};

	u32 result = 0;
	result |= parsehex(argv[3], key);
	result |= parsehex(argv[4], iv);
	if(result){
		printf("%s: Error parsing Key/IV.\n", argv[0]);
		return 0;
	}

	aes_context aes_ctxt;

	u64 size, done=0, current;
	u8 *buffer_in, *buffer_out;
	buffer_in = (u8 *)malloc(16*1024*1024);
	buffer_out = (u8 *)malloc(16*1024*1024);
	if((buffer_in == NULL) || (buffer_out == NULL))
	{
		printf("%s: Out of memory.", argv[0]);
	}
	FILE *in = fopen(argv[1],"rb");
	if(in == NULL){
		printf("%s: Could not open input file.", argv[0]);
		return 0;
	}
	FILE *out = fopen(argv[2],"wb");
	if(out == NULL){
		printf("%s: Could not open output file.", argv[0]);
		fclose(in);
		return 0;
	}
	fseek(in,0,SEEK_END);
	size=ftell(in);
	fseek(in,0,SEEK_SET);
	aes_setkey_dec(&aes_ctxt, key, 0x80);

	while(size!=done)
	{
		current=fread(buffer_in,1,16*1024*1024,in);
		done+=current;
		aes_crypt_cbc(&aes_ctxt, AES_DECRYPT, current, iv, buffer_in, buffer_out);
		fwrite(buffer_out,1,current,out);
		fprintf(stdout,"\r%s: decrypting %d%% done.",argv[0],((done*100)/size));
		fflush(stdout);
	}
	printf("\n");
	
	fclose(in);
	fclose(out);

	return 0;
}
